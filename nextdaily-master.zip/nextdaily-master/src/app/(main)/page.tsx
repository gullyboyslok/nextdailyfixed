import { EmptyPage } from '@/components/empty-page'

export default function Page() {
  return <EmptyPage />
}
